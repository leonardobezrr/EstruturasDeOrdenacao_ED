# TrabalhoED
Repositório destinado ao trabalho de estrutura de dados da primeira unidade, que envolverá os algoritmos de ordenações estudados durante a unidade
